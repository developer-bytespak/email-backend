-- AlterTable
ALTER TABLE "Summary" ALTER COLUMN "aiModel" SET DEFAULT 'gemini-1.5-flash-latest';
