-- AlterTable
ALTER TABLE "Summary" ALTER COLUMN "aiModel" SET DEFAULT 'gemini-2.0-flash-lite';
